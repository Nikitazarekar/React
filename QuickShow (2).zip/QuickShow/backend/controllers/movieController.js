import Movie from "../models/Movie.js";

// Add Movie
export const addMovie = async (req, res) => {
  const movie = new Movie(req.body);
  await movie.save();
  res.json({ message: "Movie added successfully" });
};

// Get All Movies
export const getMovies = async (req, res) => {
  const movies = await Movie.find();
  res.json(movies);
};

// Delete Movie
export const deleteMovie = async (req, res) => {
  await Movie.findByIdAndDelete(req.params.id);
  res.json({ message: "Movie deleted" });
};
