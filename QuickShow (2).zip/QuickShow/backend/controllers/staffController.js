import Staff from "../models/Staff.js";
import bcrypt from "bcryptjs";

// Register Staff
export const registerStaff = async (req, res) => {
  const { name, email, password } = req.body;

  try {
    const staffCount = await Staff.countDocuments();
    if (staffCount >= 3) {
      return res.status(400).json({ message: "Only 3 staff members allowed" });
    }

    const existingStaff = await Staff.findOne({ email });
    if (existingStaff) {
      return res.status(400).json({ message: "Email already registered" });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const staff = new Staff({
      name,
      email,
      password: hashedPassword
    });

    await staff.save();
    res.json({ message: "Staff registered successfully" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Login Staff
export const loginStaff = async (req, res) => {
  const { email, password } = req.body;

  try {
    const staff = await Staff.findOne({ email });
    if (!staff) {
      return res.status(400).json({ message: "Invalid credentials" });
    }

    const isMatch = await bcrypt.compare(password, staff.password);
    if (!isMatch) {
      return res.status(400).json({ message: "Invalid credentials" });
    }

    res.json({ message: "Login successful", staff });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Get All Staff
export const getAllStaff = async (req, res) => {
  const staff = await Staff.find();
  res.json(staff);
};

// Delete Staff
export const deleteStaff = async (req, res) => {
  await Staff.findByIdAndDelete(req.params.id);
  res.json({ message: "Staff deleted" });
};
