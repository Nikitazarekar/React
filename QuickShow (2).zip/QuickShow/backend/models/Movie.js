import mongoose from "mongoose";

const MovieSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true
  },
  genre: String,
  duration: Number,
  releaseDate: String
});

export default mongoose.model("Movie", MovieSchema);
