import express from "express";
import {
  addMovie,
  getMovies,
  deleteMovie
} from "../controllers/movieController.js";

const router = express.Router();

router.post("/", addMovie);
router.get("/", getMovies);
router.delete("/:id", deleteMovie);

export default router;
