import express from "express";
import {
  registerStaff,
  loginStaff,
  getAllStaff,
  deleteStaff
} from "../controllers/staffController.js";

const router = express.Router();

router.post("/register", registerStaff);
router.post("/login", loginStaff);
router.get("/", getAllStaff);
router.delete("/:id", deleteStaff);

export default router;
