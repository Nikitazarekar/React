import { Routes, Route } from "react-router-dom";
import { useState } from "react";
import Navbar from "./components/Navbar";
import Register from "./pages/Register";
import Login from "./pages/Login";
import Movies from "./pages/Movies";

const App = () => {
  const [isAuth, setIsAuth] = useState(!!localStorage.getItem("staff"));

  return (
    <>
      <Navbar isAuth={isAuth} setIsAuth={setIsAuth} />
      <Routes>
        <Route path="/register" element={<Register />} />
        <Route path="/login" element={<Login setIsAuth={setIsAuth} />} />
        <Route path="/movies" element={<Movies />} />
      </Routes>
    </>
  );
};

export default App;
