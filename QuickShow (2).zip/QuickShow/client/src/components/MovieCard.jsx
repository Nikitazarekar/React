const MovieCard = ({ movie, onDelete }) => {
  return (
    <div className="border p-4 rounded shadow">
      <h2 className="font-bold">{movie.title}</h2>
      <p>Genre: {movie.genre}</p>
      <p>Year: {movie.year}</p>
      <button
        onClick={() => onDelete(movie._id)}
        className="bg-red-500 text-white px-3 py-1 mt-2"
      >
        Delete
      </button>
    </div>
  );
};

export default MovieCard;
