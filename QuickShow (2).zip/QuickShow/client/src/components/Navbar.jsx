import { Link } from "react-router-dom";

const Navbar = ({ isAuth, setIsAuth }) => {
  const logout = () => {
    localStorage.removeItem("staff");
    setIsAuth(false);
  };

  return (
    <div className="bg-black text-white p-4 flex justify-between">
      <h1 className="font-bold">🎬 Movie Admin</h1>
      <div className="space-x-4">
        {!isAuth ? (
          <>
            <Link to="/register">Register</Link>
            <Link to="/login">Login</Link>
          </>
        ) : (
          <>
            <Link to="/movies">Movies</Link>
            <button onClick={logout} className="text-red-400">Logout</button>
          </>
        )}
      </div>
    </div>
  );
};

export default Navbar;
