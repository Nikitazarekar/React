import { useState } from "react";
import API from "../api/axios";
import { useNavigate } from "react-router-dom";

const Login = ({ setIsAuth }) => {
  const [form, setForm] = useState({ email: "", password: "" });
  const navigate = useNavigate();

  const submit = async (e) => {
    e.preventDefault();
    try {
      const res = await API.post("/staff/login", form);
      localStorage.setItem("staff", JSON.stringify(res.data.staff));
      setIsAuth(true);
      navigate("/movies");
    } catch (err) {
      alert("Invalid Credentials");
    }
  };

  return (
    <form onSubmit={submit} className="p-6 max-w-md mx-auto">
      <h2 className="text-xl mb-4">Staff Login</h2>
      <input placeholder="Email" className="input" onChange={e => setForm({...form,email:e.target.value})}/>
      <input type="password" placeholder="Password" className="input" onChange={e => setForm({...form,password:e.target.value})}/>
      <button className="bg-green-500 text-white px-4 py-2 mt-2">Login</button>
    </form>
  );
};

export default Login;
