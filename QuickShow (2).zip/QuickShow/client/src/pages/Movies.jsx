import { useEffect, useState } from "react";
import API from "../api/axios";

const Movies = () => {
  const [movies, setMovies] = useState([]);
  const [title, setTitle] = useState("");

  const loadMovies = async () => {
    const res = await API.get("/movies");
    setMovies(res.data);
  };

  useEffect(() => {
    loadMovies();
  }, []);

  const addMovie = async () => {
    await API.post("/movies", { title });
    setTitle("");
    loadMovies();
  };

  const deleteMovie = async (id) => {
    await API.delete(`/movies/${id}`);
    loadMovies();
  };

  return (
    <div className="p-6">
      <h2 className="text-xl mb-4">Movies</h2>

      <input
        value={title}
        onChange={e => setTitle(e.target.value)}
        placeholder="Movie Title"
        className="border p-2 mr-2"
      />
      <button onClick={addMovie} className="bg-blue-500 text-white px-3 py-2">Add</button>

      <ul className="mt-4">
        {movies.map(movie => (
          <li key={movie._id} className="flex justify-between border p-2 mb-2">
            {movie.title}
            <button onClick={() => deleteMovie(movie._id)} className="text-red-500">Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Movies;
