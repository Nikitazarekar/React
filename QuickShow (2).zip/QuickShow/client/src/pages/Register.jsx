import { useState } from "react";
import API from "../api/axios";

const Register = () => {
  const [form, setForm] = useState({ name: "", email: "", password: "" });

  const submit = async (e) => {
    e.preventDefault();
    try {
      const res = await API.post("/staff/register", form);
      alert(res.data.message);
    } catch (err) {
      alert(err.response.data.message);
    }
  };

  return (
    <form onSubmit={submit} className="p-6 max-w-md mx-auto">
      <h2 className="text-xl mb-4">Register Staff</h2>
      <input placeholder="Name" className="input" onChange={e => setForm({...form,name:e.target.value})}/>
      <input placeholder="Email" className="input" onChange={e => setForm({...form,email:e.target.value})}/>
      <input type="password" placeholder="Password" className="input" onChange={e => setForm({...form,password:e.target.value})}/>
      <button className="bg-blue-500 text-white px-4 py-2 mt-2">Register</button>
    </form>
  );
};

export default Register;
