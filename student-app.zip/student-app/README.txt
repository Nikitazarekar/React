How to Run the Project After Downloading ZIP 

Extract the ZIP file using “Extract All”.

Open the extracted folder in Terminal / CMD using:

cd path/to/project-folder


Install required Node modules by running:

npm install


Open MySQL and create the database using these commands:

CREATE DATABASE student_db;
USE student_db;

CREATE TABLE student (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    class_division VARCHAR(50) NOT NULL,
    roll_number VARCHAR(30) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


Open the file db.js and update your MySQL username and password:

user: 'root',
password: ''


(Change according to your MySQL settings.)

Start the Node.js server by running:

node server.js


After the server starts, open browser and go to:

http://localhost:3000/students


You can now:

Add Student

View Students

Edit Student

Delete Student