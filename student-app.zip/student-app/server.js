// server.js
const express = require('express');
const path = require('path');
const pool = require('./db');

const app = express();
const PORT = 3000;

// middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use('/public', express.static(path.join(__dirname, 'public')));

// Home redirect to /students
app.get('/', (req, res) => {
  res.redirect('/students');
});

/**
 * 1) Add student form (GET)
 */
app.get('/students/add', (req, res) => {
  res.render('add', { errors: null, values: {} });
});

/**
 * 1) Add student (POST)
 */
app.post('/students/add', async (req, res) => {
  const { name, class_division, roll_number } = req.body;
  const errors = [];

  if (!name || !name.trim()) errors.push('Name is required.');
  if (!class_division || !class_division.trim()) errors.push('Class and Division required.');
  if (!roll_number || !roll_number.trim()) errors.push('Roll Number required.');

  if (errors.length) {
    return res.render('add', { errors, values: req.body });
  }

  try {
    const sql = 'INSERT INTO student (name, class_division, roll_number) VALUES (?, ?, ?)';
    await pool.execute(sql, [name.trim(), class_division.trim(), roll_number.trim()]);
    res.redirect('/students');
  } catch (err) {
    console.error(err);
    res.status(500).send('Database error');
  }
});

/**
 * 2) Display page: list all students
 */
app.get('/students', async (req, res) => {
  try {
    const [rows] = await pool.execute('SELECT * FROM student ORDER BY id DESC');
    res.render('list', { students: rows });
  } catch (err) {
    console.error(err);
    res.status(500).send('Database error');
  }
});

/**
 * 3) Edit form: fetch current data
 */
app.get('/students/edit/:id', async (req, res) => {
  const id = req.params.id;
  try {
    const [rows] = await pool.execute('SELECT * FROM student WHERE id = ?', [id]);
    if (rows.length === 0) return res.status(404).send('Student not found');
    res.render('edit', { student: rows[0], errors: null });
  } catch (err) {
    console.error(err);
    res.status(500).send('Database error');
  }
});

/**
 * 3) Update student (POST)
 */
app.post('/students/edit/:id', async (req, res) => {
  const id = req.params.id;
  const { name, class_division, roll_number } = req.body;
  const errors = [];
  if (!name || !name.trim()) errors.push('Name is required.');
  if (!class_division || !class_division.trim()) errors.push('Class and Division required.');
  if (!roll_number || !roll_number.trim()) errors.push('Roll Number required.');

  if (errors.length) {
    // reload current data but show submitted values
    return res.render('edit', { student: { id, name, class_division, roll_number }, errors });
  }

  try {
    const sql = 'UPDATE student SET name = ?, class_division = ?, roll_number = ? WHERE id = ?';
    await pool.execute(sql, [name.trim(), class_division.trim(), roll_number.trim(), id]);
    res.redirect('/students');
  } catch (err) {
    console.error(err);
    res.status(500).send('Database error');
  }
});

/**
 * 4) Delete student
 * Using GET for simple demo; ideally use POST/DELETE in production with CSRF protection.
 */
app.get('/students/delete/:id', async (req, res) => {
  const id = req.params.id;
  try {
    await pool.execute('DELETE FROM student WHERE id = ?', [id]);
    res.redirect('/students');
  } catch (err) {
    console.error(err);
    res.status(500).send('Database error');
  }
});

// start server
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
